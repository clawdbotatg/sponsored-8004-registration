"use strict";(self.webpackChunk_N_E=self.webpackChunk_N_E||[]).push([[3494],{93494:(e,l,o)=>{o.r(l),o.d(l,{chevronBottomSvg:()=>a});var r=o(28312);let a=(0,r.JW)`<svg fill="none" viewBox="0 0 16 16">
  <path
    fill="currentColor"
    fill-rule="evenodd"
    d="M1.46 4.96a1 1 0 0 1 1.41 0L8 10.09l5.13-5.13a1 1 0 1 1 1.41 1.41l-5.83 5.84a1 1 0 0 1-1.42 0L1.46 6.37a1 1 0 0 1 0-1.41Z"
    clip-rule="evenodd"
  />
</svg>`}}]);